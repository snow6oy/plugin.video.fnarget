# plugin.video.fnarget

Fnarget exists to demonstrate the awesomeness of password-less login

