# plugin.video.fnarget

Fnarget exists to demonstrate the awesomeness of password-less login
```
               .------.     .---------.
kodi  -------->| IPTV |-----| Web App |         
 O             .------.     .---------.   
/|\                              |
/ \            .------.     .---------.            
user  <--------|Mobile|-----|Launchkey|
               .------.     .---------.
```
